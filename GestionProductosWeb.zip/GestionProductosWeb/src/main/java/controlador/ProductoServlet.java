package controlador;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import modelo.Producto;
import modelo.ProductoDAO;

@WebServlet("/ProductoServlet")
public class ProductoServlet extends HttpServlet {

    ProductoDAO dao = new ProductoDAO();

@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    String accion = request.getParameter("accion");
    if (accion == null || accion.equals("listar")) {
        request.setAttribute("lista", dao.listar());
        request.getRequestDispatcher("listarProductos.jsp").forward(request, response);
    } else if (accion.equals("eliminar")) {
        int id = Integer.parseInt(request.getParameter("id"));
        dao.eliminar(id);
        response.sendRedirect("ProductoServlet?accion=listar");
    } else if (accion.equals("editar")) {
        // Cargar el producto y mostrarlo en listarProductos.jsp con el formulario precargado
        int id = Integer.parseInt(request.getParameter("id"));
        Producto p = dao.buscarPorId(id);
        if (p != null) {
            request.setAttribute("producto", p); // Para precargar el formulario
        }
        request.setAttribute("lista", dao.listar()); // Mantener el listado visible
        request.getRequestDispatcher("listarProductos.jsp").forward(request, response);
    }
}    

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    String accion = request.getParameter("accion");
    String nombre = request.getParameter("nombre");
    String descripcion = request.getParameter("descripcion");
    String precioStr = request.getParameter("precio");
    String stockStr = request.getParameter("stock");
    String categoria = request.getParameter("categoria");

    // Validación básica
    boolean error = false;
    String mensajeError = "";

    // Campos obligatorios
    if (nombre == null || nombre.trim().isEmpty()) {
        mensajeError = "El nombre es obligatorio.";
        error = true;
    } else if (precioStr == null || precioStr.trim().isEmpty()) {
        mensajeError = "El precio es obligatorio.";
        error = true;
    } else if (stockStr == null || stockStr.trim().isEmpty()) {
        mensajeError = "El stock es obligatorio.";
        error = true;
    } else if (categoria == null || categoria.trim().isEmpty()) {
        mensajeError = "La categoría es obligatoria.";
        error = true;
    }

    // Validar formato numérico y positivo
    double precio = 0;
    int stock = 0;
    if (!error) {
        try {
            precio = Double.parseDouble(precioStr);
            if (precio <= 0) {
                mensajeError = "El precio debe ser mayor que 0.";
                error = true;
            }
        } catch (NumberFormatException e) {
            mensajeError = "El precio debe ser un número válido.";
            error = true;
        }
    }
    if (!error) {
        try {
            stock = Integer.parseInt(stockStr);
            if (stock < 0) {
                mensajeError = "El stock no puede ser negativo.";
                error = true;
            }
        } catch (NumberFormatException e) {
            mensajeError = "El stock debe ser un número entero válido.";
            error = true;
        }
    }

    if (error) {
        // Volver al formulario con el mensaje de error
        request.setAttribute("mensajeError", mensajeError);
        if ("actualizar".equals(accion)) {
            // Volver a cargar el formulario de edición con los datos anteriores
            Producto p = new Producto();
            p.setID_producto(Integer.parseInt(request.getParameter("id")));
            p.setNombre(nombre);
            p.setDescripcion(descripcion);
            p.setPrecio(precio);
            p.setStock(stock);
            p.setCategoria(categoria);
            request.setAttribute("producto", p);
            request.getRequestDispatcher("editarProducto.jsp").forward(request, response);
        } else {
            // Formulario de nuevo producto
            request.getRequestDispatcher("nuevoProducto.jsp").forward(request, response);
        }
        return;
    }

    // Si no hay errores, procesar la acción
    if ("agregar".equals(accion)) {
        Producto p = new Producto();
        p.setNombre(nombre.trim());
        p.setDescripcion(descripcion != null ? descripcion.trim() : "");
        p.setPrecio(precio);
        p.setStock(stock);
        p.setCategoria(categoria.trim());
        dao.agregar(p);
        response.sendRedirect("ProductoServlet?accion=listar");
    } else if ("actualizar".equals(accion)) {
        Producto p = new Producto();
        p.setID_producto(Integer.parseInt(request.getParameter("id")));
        p.setNombre(nombre.trim());
        p.setDescripcion(descripcion != null ? descripcion.trim() : "");
        p.setPrecio(precio);
        p.setStock(stock);
        p.setCategoria(categoria.trim());
        dao.actualizar(p);
        response.sendRedirect("ProductoServlet?accion=listar");
    }
}
}
